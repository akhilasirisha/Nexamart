package com.example.demo.Entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="jwt_tokens")
public class JwtTokens {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer tokenid;
	
	@ManyToOne
	@JoinColumn(name = "user_id",nullable = false)
	private User user;
	
	@Column(nullable = false)
	private String token;
	
	@Column(nullable = false)
	private LocalDateTime expiresat;

	public JwtTokens(Integer tokenid, User user, String token, LocalDateTime expiresat) {
		super();
		this.tokenid = tokenid;
		this.user = user;
		this.token = token;
		this.expiresat = expiresat;
	}

	public JwtTokens() {
		super();
		// TODO Auto-generated constructor stub
	}

	public JwtTokens(User user, String token, LocalDateTime expiresat) {
		super();
		this.user = user;
		this.token = token;
		this.expiresat = expiresat;
	}

	public Integer getTokenid() {
		return tokenid;
	}

	public void setTokenid(Integer tokenid) {
		this.tokenid = tokenid;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public LocalDateTime getExpiresat() {
		return expiresat;
	}

	public void setExpiresat(LocalDateTime expiresat) {
		this.expiresat = expiresat;
	}

	
	
}
