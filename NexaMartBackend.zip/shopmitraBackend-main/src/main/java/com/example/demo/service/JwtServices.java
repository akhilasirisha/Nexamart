package com.example.demo.service;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.JwtTokens;
import com.example.demo.Entity.User;
import com.example.demo.Repository.JwtRepository;
import com.example.demo.Repository.UserRespository;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

@Service
public class JwtServices {

    private final Key SIGNING_KEY;
    private final UserRespository userRepository;
    private final JwtRepository jwtTokenRepository;
    private final BCryptPasswordEncoder passwordEncoder;

  
    public JwtServices(UserRespository userRepository,
                       JwtRepository jwtTokenRepository,
                       @Value("${jwt.secret}") String jwtSecret) {

        this.userRepository = userRepository;
        this.jwtTokenRepository = jwtTokenRepository;
        this.passwordEncoder = new BCryptPasswordEncoder();

        if (jwtSecret.getBytes(StandardCharsets.UTF_8).length < 64) {
            throw new IllegalArgumentException(
                "JWT_SECRET must be at least 64 bytes long for HS512."
            );
        }

        this.SIGNING_KEY =
            Keys.hmacShaKeyFor(jwtSecret.getBytes(StandardCharsets.UTF_8));
    }

    // ================= AUTHENTICATE =================
    public User authenticate(String username, String password) {

        User user = userRepository.findByUsername(username)
                .orElseThrow(() ->
                        new RuntimeException("Invalid username or password"));

        if (!passwordEncoder.matches(password, user.getPassword())) {
            throw new RuntimeException("Invalid username or password");
        }

        return user;
    }

    // ================= GENERATE TOKEN =================
    public String generateToken(User user) {

        String token;
        LocalDateTime now = LocalDateTime.now();

        JwtTokens existingToken =
                jwtTokenRepository.findByUserid(user.getUserid());

        if (existingToken != null &&
            now.isBefore(existingToken.getExpiresat())) {

            token = existingToken.getToken();

        } else {

            token = generateNewToken(user);

            if (existingToken != null) {
                jwtTokenRepository.delete(existingToken);
            }

            saveToken(user, token);
        }

        return token;
    }

    private String generateNewToken(User user) {

        return Jwts.builder()
                .setSubject(user.getUsername())
                .claim("role", user.getRole().name())
                .setIssuedAt(new Date())
                .setExpiration(
                        new Date(System.currentTimeMillis() + 3600000)) // 1 hour
                .signWith(SIGNING_KEY, SignatureAlgorithm.HS512)
                .compact();
    }

    public void saveToken(User user, String token) {

        JwtTokens jwtToken =
                new JwtTokens(user, token,
                        LocalDateTime.now().plusHours(1));

        jwtTokenRepository.save(jwtToken);
    }

    // ================= LOGOUT =================
    public void logout(String token) {

        Optional<JwtTokens> jwtToken =
                jwtTokenRepository.findByToken(token);

        jwtToken.ifPresent(jwtTokenRepository::delete);
    }

    // ================= VALIDATE TOKEN =================
    public boolean validateToken(String token) {

        try {

            Jwts.parserBuilder()
                    .setSigningKey(SIGNING_KEY)
                    .build()
                    .parseClaimsJws(token);

            Optional<JwtTokens> jwtToken =
                    jwtTokenRepository.findByToken(token);

            return jwtToken.isPresent() &&
                   jwtToken.get().getExpiresat()
                           .isAfter(LocalDateTime.now());

        } catch (Exception e) {
            return false;
        }
    }

    // ================= EXTRACT USERNAME =================
    public String extractUsername(String token) {

        return Jwts.parserBuilder()
                .setSigningKey(SIGNING_KEY)
                .build()
                .parseClaimsJws(token)
                .getBody()
                .getSubject();
    }
}