package com.example.demo.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.User;
import com.example.demo.service.UserService;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:3000")
public class UserController {
	
	@Autowired
	private UserService userser;
	
	@PostMapping("/register")
	public ResponseEntity<?> registerUser(@RequestBody User user) {
		try {
			User registeredUser = userser.registerUser(user);
			return ResponseEntity.ok(Map.of("message","User registerd successfully","user",registeredUser));
			} catch (Exception e) {
			    e.printStackTrace(); 
			    return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
			}
	}
	
	 @GetMapping("/profile")
	    public ResponseEntity<Map<String, Object>> getProfile(HttpServletRequest request) {

	        User user = (User) request.getAttribute("authenticatedUser");

	        if (user == null) {
	            return ResponseEntity.status(401)
	                    .body(Map.of("error", "User not authenticated"));
	        }

	        Map<String, Object> response = new HashMap<>();
	        response.put("username", user.getUsername());
	        response.put("email", user.getEmail());
	        response.put("role", user.getRole());

	        return ResponseEntity.ok(response);
	    }
	}


