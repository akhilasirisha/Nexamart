package com.example.demo.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.Entity.JwtTokens;

public interface JwtRepository extends JpaRepository<JwtTokens,Integer>{
	@Query("SELECT t FROM JwtTokens t WHERE t.user.userid = :userid")
	JwtTokens findByUserid(@Param("userid")int userid);

	Optional<JwtTokens> findByToken(String token);
	  @Modifying
	    @Transactional
	    @Query("DELETE FROM JwtTokens t WHERE t.user.userid = :userId")
	    void deleteByUserId(@Param("userId") int userId);

}
