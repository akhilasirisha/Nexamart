package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.User;
import com.example.demo.Repository.UserRespository;

@Service
public class UserService {
	
	@Autowired
	private UserRespository userrepo;
	
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;
	
	public User registerUser(User user) {
		
	if(userrepo.findByEmail(user.getEmail()).isPresent()) {
	throw new RuntimeException("Email is alredy Extis");
	}
	
	if(userrepo.findByUsername(user.getUsername()).isPresent()) {
		throw new RuntimeException("Username is alredy Extis");
	}
	
	user.setPassword(passwordEncoder.encode(user.getPassword()));
	
	return userrepo.save(user);
}
}

