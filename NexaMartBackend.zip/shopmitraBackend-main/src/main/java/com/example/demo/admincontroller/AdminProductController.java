package com.example.demo.admincontroller;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Entity.Product;
import com.example.demo.adminservice.AdminProductService;

@RestController
@RequestMapping("/api/admin/products")
@CrossOrigin(origins = "http://localhost:3000")
public class AdminProductController {

    private final AdminProductService adminProductService;

    public AdminProductController(AdminProductService adminProductService) {
        this.adminProductService = adminProductService;
    }

    // ===== ADD PRODUCT =====
    @PostMapping("/add")
    public ResponseEntity<?> addProduct(@RequestBody Map<String, Object> productRequest) {

        try {

            String name = (String) productRequest.get("name");
            String description = (String) productRequest.get("description");
            Double price = Double.valueOf(productRequest.get("price").toString());
            Integer stock = Integer.valueOf(productRequest.get("stock").toString());
            Integer categoryId = Integer.valueOf(productRequest.get("categoryId").toString());
            String imageUrl = (String) productRequest.get("imageUrl");

            Product product = adminProductService.addProductWithImage(
                    name,
                    description,
                    price,
                    stock,
                    categoryId,
                    imageUrl
            );

            return ResponseEntity
                    .status(HttpStatus.CREATED)
                    .body(product);

        } catch (IllegalArgumentException e) {

            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(e.getMessage());

        } catch (Exception e) {

            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Something went wrong");
        }
    }


    // ===== DELETE PRODUCT =====
    @DeleteMapping("/delete/{productId}")
    public ResponseEntity<?> deleteProduct(@PathVariable Integer productId) {

        try {

            adminProductService.deleteProduct(productId);

            return ResponseEntity
                    .ok("Product deleted successfully");

        } catch (IllegalArgumentException e) {

            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body(e.getMessage());

        } catch (Exception e) {

            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Something went wrong");
        }
    }
}