package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Category;
import com.example.demo.Entity.Product;
import com.example.demo.Entity.ProductImage;
import com.example.demo.Repository.CategoryRepository;
import com.example.demo.Repository.ProductImageRepository;
import com.example.demo.Repository.ProductRepository;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private ProductImageRepository productImageRepository;

    @Autowired
    private CategoryRepository categoryRepository;


    // GET PRODUCTS BY CATEGORY
    public List<Product> getProductsByCategory(String categoryName) {

        if (categoryName != null && !categoryName.isEmpty()) {

            Optional<Category> categoryOpt =
                    categoryRepository.findByCategoryName(categoryName);

            if (categoryOpt.isPresent()) {

                Category category = categoryOpt.get();

                return productRepository
                        .findByCategory_CategoryId(category.getCategoryId());

            } else {
                throw new RuntimeException("Category not found");
            }

        } else {
            return productRepository.findAll();
        }
    }


    // GET PRODUCT IMAGES
    public List<String> getProductImages(Integer productId) {

        List<ProductImage> productImages =
                productImageRepository.findByProduct_ProductId(productId);

        List<String> imageUrls = new ArrayList<>();

        for (ProductImage image : productImages) {
            imageUrls.add(image.getImageUrl());
        }

        return imageUrls;
    }
    public List<Product> getProductsByCategory1(String category) {
        return productRepository.findByCategory(category);
    }
}
