package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.Entity.cartItem;

public interface CartItemRepository extends JpaRepository<cartItem, Integer>{
	  // Custom query to count cart items for a given userId
    @Query("SELECT COUNT(c) FROM CartItem c WHERE c.user.id = :userId")
    int countCartItemsByUserId(@Param("userId") int userId);

    // Custom query to fetch userId by username (assumes relationship exists)
    @Query("SELECT u.id FROM User u WHERE u.username = :username")
    int findUserIdByUsername(@Param("username") String username);
	

}
