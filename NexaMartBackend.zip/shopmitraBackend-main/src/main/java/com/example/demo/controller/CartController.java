package com.example.demo.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.User;
import com.example.demo.Repository.UserRespository;
import com.example.demo.service.CartService;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@CrossOrigin(origins = "http://localhost:3000", allowCredentials = "true")
@RequestMapping("/api/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    @Autowired
    private UserRespository userRepository;


    // ===== Fetch userId from username coming from filter and get cart item count =====
    @GetMapping("/items/count")
    public ResponseEntity<Integer> getCartItemCount(@RequestParam String username) {

        // Fetch user by username
        User user = userRepository.findByUsername(username)
                .orElseThrow(() ->
                        new IllegalArgumentException("User not found with username: " + username));

        // Call service to get total cart item count
        int count = cartService.getCartItemCount(user.getUserid());

        return ResponseEntity.ok(count);
    }


    // ===== Fetch all cart items for the user (based on username) =====
    @GetMapping("/items")
    public ResponseEntity<Map<String, Object>> getCartItems(HttpServletRequest request) {

        // Fetch user by username (authenticated user)
        User user = (User) request.getAttribute("authenticatedUser");

        if (user == null) {
            throw new IllegalArgumentException("User not found");
        }

        // Call service to get cart items
        Map<String, Object> cartItems =
                cartService.getCartItems(user.getUserid());

        return ResponseEntity.ok(cartItems);
    }


    // ===== Add an item to the cart =====
    @PostMapping("/add")
    public ResponseEntity<Void> addToCart(
            @RequestBody Map<String, Object> request,
            HttpServletRequest httpRequest) {

        // ⭐ GET LOGGED USER FROM FILTER
        User user =
            (User) httpRequest.getAttribute("authenticatedUser");

        if (user == null) {
            throw new IllegalArgumentException("User not logged in");
        }

        int productId = (int) request.get("productId");

        int quantity = request.containsKey("quantity")
                ? (int) request.get("quantity")
                : 1;

        cartService.addToCart(user.getUserid(), productId, quantity);

        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    // ===== Update Cart Item Quantity =====
    @PutMapping("/update")
    public ResponseEntity<Void> updateCartItemQuantity(
            @RequestBody Map<String, Object> request,
            HttpServletRequest httpRequest) {

        User user =
            (User) httpRequest.getAttribute("authenticatedUser");

        if (user == null) {
            throw new IllegalArgumentException("User not logged in");
        }

        int productId = (int) request.get("productId");
        int quantity = (int) request.get("quantity");

        cartService.updateCartItemQuantity(
                user.getUserid(),
                productId,
                quantity
        );

        return ResponseEntity.ok().build();
    }


    // ===== Delete Cart Item =====
    @DeleteMapping("/delete")
    public ResponseEntity<Void> deleteCartItem(
            @RequestBody Map<String, Object> request,
            HttpServletRequest httpRequest) {

        User user =
            (User) httpRequest.getAttribute("authenticatedUser");

        if (user == null) {
            throw new IllegalArgumentException("User not logged in");
        }

        int productId = (int) request.get("productId");

        cartService.deleteCartItem(user.getUserid(), productId);

        return ResponseEntity.ok().build();
    }
}