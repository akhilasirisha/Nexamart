package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

 @SpringBootApplication
public class ShopMitraApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShopMitraApplication.class, args);
	}

}
