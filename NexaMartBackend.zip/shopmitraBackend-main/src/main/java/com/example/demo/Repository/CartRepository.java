package com.example.demo.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.Entity.cartItem;

import jakarta.transaction.Transactional;

public interface CartRepository extends JpaRepository<cartItem, Integer> {


	    @Query("SELECT c FROM CartItem c WHERE c.user.userid = :userId AND c.product.productId = :productId")
	    Optional<cartItem> findByUserAndProduct(int userId, int productId);

	    @Query("SELECT c FROM CartItem c JOIN FETCH c.product WHERE c.user.userid = :userId")
	    List<cartItem> findCartItemsWithProductDetails(int userId);

	    @Modifying
	    @Transactional
	    @Query("DELETE FROM CartItem c WHERE c.user.userid = :userId AND c.product.productId = :productId")
	    void deleteCartItem(int userId, int productId);

	    @Query("SELECT COALESCE(SUM(c.quantity),0) FROM CartItem c WHERE c.user.userid = :userId")
	    int countTotalItems(int userId);
	    
	  
	    @Transactional
	    @Modifying
	    @Query("DELETE FROM CartItem c WHERE c.user.userid = :userId")
	    void deleteAllCartItemsByUserId(@Param("userId") int userId);
	}

