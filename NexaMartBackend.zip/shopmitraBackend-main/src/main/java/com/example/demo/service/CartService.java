package com.example.demo.service;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Product;
import com.example.demo.Entity.ProductImage;
import com.example.demo.Entity.User;
import com.example.demo.Entity.cartItem;
import com.example.demo.Repository.CartRepository;
import com.example.demo.Repository.ProductImageRepository;
import com.example.demo.Repository.ProductRepository;
import com.example.demo.Repository.UserRespository;

@Service
public class CartService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private UserRespository userRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private ProductImageRepository productImageRepository;


    // ===== Get total cart item count =====
    public int getCartItemCount(int userId) {
        return cartRepository.countTotalItems(userId);
    }


    // ===== Add item to cart =====
    public void addToCart(int userId, int productId, int quantity) {

        User user = userRepository.findById(userId)
                .orElseThrow(() ->
                        new IllegalArgumentException("User not found with ID: " + userId));

        Product product = productRepository.findById(productId)
                .orElseThrow(() ->
                        new IllegalArgumentException("Product not found with ID: " + productId));

        Optional<cartItem> existingItem =
                cartRepository.findByUserAndProduct(userId, productId);

        if (existingItem.isPresent()) {

            cartItem item = existingItem.get();
            item.setQuantity(item.getQuantity() + quantity);
            cartRepository.save(item);

        } else {

            cartItem newItem = new cartItem();
            newItem.setUser(user);
            newItem.setProduct(product);
            newItem.setQuantity(quantity);

            cartRepository.save(newItem);
        }
    }


    // ===== Get Cart Items =====
    public Map<String, Object> getCartItems(int userId) {

        List<cartItem> cartItems =
                cartRepository.findCartItemsWithProductDetails(userId);

        Map<String, Object> response = new HashMap<>();

        User user = userRepository.findById(userId)
                .orElseThrow(() ->
                        new IllegalArgumentException("User not found"));

        response.put("username", user.getUsername());
        response.put("user_id", user.getUserid());

        List<Map<String, Object>> products = new ArrayList<>();

        double overallTotalPrice = 0;

        for (cartItem item : cartItems) {

            Map<String, Object> productDetails = new HashMap<>();

            Product product = item.getProduct();

            // Fetch image
            List<ProductImage> images =
                    productImageRepository.findByProduct_ProductId(
                            product.getProductId());

            String imageUrl =
                    (images != null && !images.isEmpty())
                            ? images.get(0).getImageUrl()
                            : "default-image-url";

            productDetails.put("product_id", product.getProductId());
            productDetails.put("image_url", imageUrl);
            productDetails.put("name", product.getName());
            productDetails.put("description", product.getDescription());
            productDetails.put("price_per_unit", product.getPrice());
            productDetails.put("quantity", item.getQuantity());

            double total =
                    item.getQuantity() * product.getPrice().doubleValue();

            productDetails.put("total_price", total);

            products.add(productDetails);

            overallTotalPrice += total;
        }

        Map<String, Object> cart = new HashMap<>();
        cart.put("products", products);
        cart.put("overall_total_price", overallTotalPrice);

        response.put("cart", cart);

        return response;
    }


    // ===== Update Cart Quantity =====
    public void updateCartItemQuantity(int userId, int productId, int quantity) {

        Optional<cartItem> existingItem =
                cartRepository.findByUserAndProduct(userId, productId);

        if (existingItem.isPresent()) {

            cartItem item = existingItem.get();

            if (quantity == 0) {
                deleteCartItem(userId, productId);
            } else {
                item.setQuantity(quantity);
                cartRepository.save(item);
            }
        }
    }


    // ===== Delete Cart Item =====
    public void deleteCartItem(int userId, int productId) {
        cartRepository.deleteCartItem(userId, productId);
    }
}