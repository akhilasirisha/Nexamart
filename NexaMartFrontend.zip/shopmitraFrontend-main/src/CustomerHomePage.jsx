import React, { useEffect, useState } from "react";

import "./styles.css";
function CustomerHomePage() {

  const [products, setProducts] = useState([]);
  const [category, setCategory] = useState("All");

  useEffect(() => {

    fetch("http://localhost:9091/api/products", {
      credentials: "include"
    })
    .then(res => res.json())
    .then(data => {
      setProducts(data.products);
    });

  }, []);

  const filteredProducts =
    category === "All"
      ? products
      : products.filter(
          p => p.category?.toLowerCase() === category.toLowerCase()
        );

  return (
    <div>

      {/* CATEGORY NAVBAR */}
      <div className="navigation">

        <ul className="category-list">

          <li className="category-item" onClick={() => setCategory("All")}>
            All
          </li>

          <li className="category-item" onClick={() => setCategory("Shirts")}>
            Shirts
          </li>

          <li className="category-item" onClick={() => setCategory("Pants")}>
            Pants
          </li>

          <li className="category-item" onClick={() => setCategory("Mobiles")}>
            Mobiles
          </li>

          <li className="category-item" onClick={() => setCategory("Accessories")}>
            Accessories
          </li>

        </ul>

      </div>


      {/* PRODUCTS */}
      <div className="product-grid">

        {filteredProducts.map(product => (

          <div key={product.product_id} className="product-card">

            <img
              src={product.images[0]}
              alt={product.name}
              style={{ width: "200px" }}
            />

            <h3>{product.name}</h3>

            <p>{product.description}</p>

            <h2>₹{product.price}</h2>

            <button>Add to Cart</button>

          </div>

        ))}

      </div>

    </div>
  );
}

export default CustomerHomePage; 
