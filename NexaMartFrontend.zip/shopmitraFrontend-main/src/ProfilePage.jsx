import React from "react";
import { useNavigate } from "react-router-dom";
import "./ProfilePage.css";


function ProfilePage() {

  const navigate = useNavigate();

  const username = localStorage.getItem("username");
  const email = localStorage.getItem("email");
  const role = localStorage.getItem("role");

  return (
    <div className="profile-page">

      <div className="page-bg-text">ShopMitra</div>

      <h2>My Profile</h2>

      <div className="profile-card">
        <p><b>Name:</b> {username || "N/A"}</p>
        <p><b>Email:</b> {email || "N/A"}</p>
        <p><b>Role:</b> {role || "N/A"}</p>
      </div>

      <div className="profile-actions">
        <button onClick={() => navigate("/products")}>
          Continue Shopping
        </button>
      </div>

    </div>
  );
}

export default ProfilePage;