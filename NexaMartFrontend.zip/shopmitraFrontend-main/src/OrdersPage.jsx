import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./OrdersPage.css";


function OrdersPage() {

  const [orders, setOrders] = useState([]);
  const [username, setUsername] = useState("");

  const navigate = useNavigate();

  useEffect(() => {
    fetch("http://localhost:9091/api/orders", {
      credentials: "include"
    })
      .then(res => res.json())
      .then(data => {
        console.log("ORDERS RESPONSE:", data);

        setUsername(data.username || "");
        setOrders(data.products || []);
      })
      .catch(err => console.error(err));
  }, []);

  return (
    <div className="orders-page">
            <div className="page-bg-text">ShopMitra</div>
         <button
    className="back-profile-btn"
    onClick={() => navigate("/products")}
  >
    ← Back to Shopping
  </button>

      <h2>My Orders</h2>

      {orders.length === 0 ? (
        <div className="empty-orders">
          <h3>No Orders Found 😢</h3>
          <button onClick={() => navigate("/products")}>
            Continue Shopping
          </button>
        </div>
      ) : (

        <div className="orders-container">

          {orders.map((item, index) => (
            <div className="order-card" key={index}>

              <img
                src={item.image_url}
                alt={item.name}
                className="order-img"
              />
              

              <div className="order-info">
                <h3>{item.name}</h3>
                <p>{item.description}</p>

                <p>Qty: {item.quantity}</p>
                <p>Order ID: {item.order_id}</p>
              </div>

              <h4>₹{Number(item.total_price).toFixed(2)}</h4>
              

            </div>
            
          ))}

        </div>
      )}
    </div>
  );
}

export default OrdersPage;