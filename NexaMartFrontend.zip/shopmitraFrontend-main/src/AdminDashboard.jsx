import React from "react";
import { Link } from "react-router-dom";
import "./AdminDashboard.css";

function AdminDashboard(){

  return(

    <div className="admin-dashboard">

      {/* SIDEBAR */}

      <div className="admin-sidebar">

        <h2 className="admin-logo">ShopMitra Admin</h2>

        <ul>

          <li>
            <Link to="/admin/products">Products</Link>
          </li>

          <li>
            <Link to="/admin/orders">Orders</Link>
          </li>

          <li>
            <Link to="/admin/users">Users</Link>
          </li>

        </ul>

      </div>


      {/* CONTENT */}

      <div className="admin-content">

        <h1>Admin Dashboard</h1>

        <div className="admin-cards">

          <div className="admin-card">
            <h3>Products</h3>
            <p>Manage all products</p>
          </div>

          <div className="admin-card">
            <h3>Orders</h3>
            <p>View customer orders</p>
          </div>

          <div className="admin-card">
            <h3>Users</h3>
            <p>Manage customers</p>
          </div>

        </div>

      </div>

    </div>
  )
}

export default AdminDashboard;