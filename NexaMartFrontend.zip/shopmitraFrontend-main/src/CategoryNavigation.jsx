import React from "react";

function CategoryNavigation({ setCategory, activeCategory }) {

  const categories = [
    "All",
    "Shirts",
    "Pants",
    "Accessories",
    "Mobiles",
    "Mobile Accessories"
  ];

  return (
    <div className="navigation">
      <ul className="category-list">

        {categories.map((cat) => (
          <li
            key={cat}
            className={`category-item ${activeCategory === cat ? "active" : ""}`}
            onClick={() => setCategory(cat)}
          >
            {cat}
          </li>
        ))}

      </ul>
    </div>
  );
}

export default CategoryNavigation;