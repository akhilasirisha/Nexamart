import React, { useState } from "react";
import "./RegisterForm.css";
import { Link } from "react-router-dom";

export default function RegisterForm() {

  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
    role: ""
  });

  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  // handle input change
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  // submit form
  const handleSubmit = async (e) => {
    e.preventDefault();

    setMessage("");
    setError("");

    try {
      const response = await fetch("http://localhost:9091/api/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(formData)
      });

      const data = await response.json();

      if (response.ok) {

        setMessage("User registered successfully");

        setFormData({
          username: "",
          email: "",
          password: "",
          role: ""
        });

      } else {
        setError(data.error || "Registration failed");
      }

    } catch (error) {
      console.error(error);
      setError("Server Error. Please try again.");
    }
  };

  return (
    <div className="page">

      <div className="register-container">

        <div className="page-bg-text">ShopMitra</div>

        <div className="register-card">

          <h1 className="title">Register</h1>

          {/* SUCCESS MESSAGE */}
          {message && (
            <p className="success-message">
              {message}
            </p>
          )}

          {/* ERROR MESSAGE */}
          {error && (
            <p className="error-message">
              {error}
            </p>
          )}

          <form className="register-form" onSubmit={handleSubmit}>

            <div className="form-group">
              <label>Username</label>
              <input
                type="text"
                name="username"
                placeholder="Enter username"
                value={formData.username}
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-group">
              <label>Email</label>
              <input
                type="email"
                name="email"
                placeholder="Enter email"
                value={formData.email}
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-group">
              <label>Password</label>
              <input
                type="password"
                name="password"
                placeholder="Enter password"
                value={formData.password}
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-group">
              <label>Role</label>
              <select
                name="role"
                value={formData.role}
                onChange={handleChange}
                required
              >
                <option value="">Select Role</option>
                <option value="ADMIN">Admin</option>
                <option value="CUSTOMER">Customer</option>
              </select>
            </div>

            <button type="submit" className="submit-btn">
              Create Account
            </button>

          </form>

          <p className="login-link">
            You have Already Account? <Link to="/login">Log in here</Link>
          </p>

        </div>

      </div>

    </div>
  );
}