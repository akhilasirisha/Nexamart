import React, { useState } from "react";
import "./AdminProducts.css";

function AdminProducts() {

  const [product,setProduct]=useState({
    name:"",
    description:"",
    price:"",
    stock:"",
    categoryId:"",
    imageUrl:""
  });

  const [deleteId,setDeleteId]=useState("");

  const handleChange=(e)=>{
    setProduct({
      ...product,
      [e.target.name]:e.target.value
    });
  };

  const addProduct=async()=>{

    const response = await fetch("http://localhost:9091/api/admin/products/add", {
  method: "POST",
  headers: {
    "Content-Type": "application/json"
  },
  credentials: "include",
  body: JSON.stringify(product)
});

    if(response.ok){
      alert("Product added successfully");
    }else{
      alert("Error adding product");
    }
  };

  const deleteProduct=async()=>{

    const response=await fetch(
  `http://localhost:9091/api/admin/products/delete/${deleteId}`,
  {
    method: "DELETE",
    credentials: "include"
  }
);

    if(response.ok){
      alert("Product deleted");
    }else{
      alert("Error deleting product");
    }
  };

  return(

    <div className="admin-page">

      <div className="admin-container">

        <h2 className="admin-title">Admin Product Management</h2>

        {/* ADD PRODUCT */}

        <div className="admin-section">

          <h3>Add Product</h3>

          <input
            className="admin-input"
            name="name"
            placeholder="Product Name"
            onChange={handleChange}
          />

          <input
            className="admin-input"
            name="description"
            placeholder="Description"
            onChange={handleChange}
          />

          <input
            className="admin-input"
            name="price"
            placeholder="Price"
            onChange={handleChange}
          />

          <input
            className="admin-input"
            name="stock"
            placeholder="Stock"
            onChange={handleChange}
          />

          <input
            className="admin-input"
            name="categoryId"
            placeholder="Category ID"
            onChange={handleChange}
          />

          <input
            className="admin-input"
            name="imageUrl"
            placeholder="Image URL"
            onChange={handleChange}
          />

          <button className="admin-btn" onClick={addProduct}>
            Add Product
          </button>

        </div>


        <div className="admin-divider"></div>


        {/* DELETE PRODUCT */}

        <div className="admin-section">

          <h3>Delete Product</h3>

          <input
            className="admin-input"
            placeholder="Enter Product ID"
            onChange={(e)=>setDeleteId(e.target.value)}
          />

          <button className="admin-btn" onClick={deleteProduct}>
            Delete Product
          </button>

        </div>

      </div>

    </div>

  );
}

export default AdminProducts;