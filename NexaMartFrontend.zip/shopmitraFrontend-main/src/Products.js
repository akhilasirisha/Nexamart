import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { FaShoppingCart, FaUser } from "react-icons/fa";
import "./Products.css";
// import "./styles.css";
import CategoryNavigation from "./CategoryNavigation";

function Products() {

  const [products, setProducts] = useState([]);
  const [cartCount, setCartCount] = useState(0);
  const [username, setUsername] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [category, setCategory] = useState("All");

  const navigate = useNavigate();

  // ===== LOGOUT =====
  const handleLogout = async () => {
    try {
      await fetch("http://localhost:9091/api/logout", {
        method: "POST",
        credentials: "include"
      });

      localStorage.clear();
      navigate("/login");

    } catch (error) {
      console.error("Logout error:", error);
    }
  };

  // ===== LOAD USERNAME =====
  useEffect(() => {
    const user = localStorage.getItem("username");
    setUsername(user);
  }, []);

  // ===== LOAD CART COUNT =====
  const loadCartCount = () => {
    const user = localStorage.getItem("username");
    if (!user) return;

   fetch("http://localhost:9091/api/cart/items/count?username=" + user, {
  headers: {
    "Authorization": "Bearer " + localStorage.getItem("token")
  },
  credentials: "include"
})
      .then(res => res.json())
      .then(data => setCartCount(data))
      .catch(err => console.error(err));
  };

  // ===== LOAD PRODUCTS =====
  useEffect(() => {

   fetch("http://localhost:9091/api/products", {
  method: "GET",
  headers: {
    "Authorization": "Bearer " + localStorage.getItem("token")
  },
  credentials: "include"
})
      .then(res => res.json())
      .then(data => {
        setProducts(
          Array.isArray(data) ? data : data.products || []
        );
      })
      .catch(err => console.error(err));

    loadCartCount();

  }, []);

  // ===== ADD TO CART =====
  const addToCart = (productId) => {

    const user = localStorage.getItem("username");

   fetch("http://localhost:9091/api/cart/add", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    "Authorization": "Bearer " + localStorage.getItem("token")
  },
  credentials: "include",
  body: JSON.stringify({
    username: user,
    productId,
    quantity: 1
  })
})
      .then(() => loadCartCount())
      .catch(err => console.error(err));
  };
 const filteredProducts =
  category === "All"
    ? products
    : products.filter(
        product =>
          product.category &&
          product.category.toLowerCase() === category.toLowerCase()
      );

  return (
    <div className="products-page">

      {/* ===== NAVBAR ===== */}
      <nav className="navbar">

    <h2 className="logo">ShopMitra</h2>

        <div className="nav-links">

          {/* CART */}
          <Link to="/UserCartPage" className="cart-link">
            <FaShoppingCart />
            {cartCount > 0 && (
              <span className="cart-badge">{cartCount}</span>
            )}
          </Link>

          {/* PROFILE DROPDOWN */}
         <div className="profile-dropdown">

  <div
    className="profile-icon"
    onClick={() => setIsOpen(!isOpen)}
  >
    <FaUser className="user-icon" />
    <span className="username">
      {username || "Guest"}
    </span>
  </div>

  {isOpen && (
    <div className="dropdown-menu">

      <button
        className="dropdown-item"
        onClick={() => navigate("/orders")}
      >
        My Orders
      </button>

      <button
        className="dropdown-item"
        onClick={() => navigate("/profile")}
      >
        Profile
      </button>

      <button
        className="dropdown-item logout"
        onClick={handleLogout}
      >
        Logout
      </button>

    </div>
  )}

</div>

        </div>
      </nav>
      
      <div className="category-wrapper">
  <CategoryNavigation
    setCategory={setCategory}
    activeCategory={category}
  />
</div>

      {/* ===== PRODUCTS ===== */}
      <div className="products-grid">
{filteredProducts.map(product => (
      <div className="product-card" key={product.product_id}>

  <img
    className="product-img"
    src={product.images?.[0]}
    alt={product.name}
  />

  <div className="product-info">
    <h3>{product.name}</h3>

    <p>{product.description}</p>

    <div className="product-price">
      ₹{Number(product.price).toFixed(2)}
    </div>

    <button
      className="cart-btn"
      onClick={() => addToCart(product.product_id)}
    >
      Add to Cart
    </button>
  </div>

</div>
        ))}

      </div>

    </div>
  );
}

export default Products;