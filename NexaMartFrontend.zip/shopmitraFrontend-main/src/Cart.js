import React, { useEffect, useState } from "react";

function Cart() {

  const [cart, setCart] = useState([]);
  const [total, setTotal] = useState(0);

  const username = localStorage.getItem("username");

  // ===== LOAD CART =====
  const loadCart = () => {

    fetch("http://localhost:9091/api/cart/items", {
      credentials: "include"
    })
      .then(res => res.json())
      .then(data => {
        setCart(data.cart.products || []);
        setTotal(data.cart.overall_total_price || 0);
      });
  };

  useEffect(() => {
    loadCart();
  }, []);

  // ===== UPDATE QTY =====
  const updateQty = (productId, quantity) => {

    fetch("http://localhost:9091/api/cart/update", {
      method: "PUT",
      headers: {
        "Content-Type": "application/json"
      },
      credentials: "include",
      body: JSON.stringify({
        username: username,
        productId: productId,
        quantity: quantity
      })
    }).then(loadCart);
  };

  // ===== DELETE ITEM =====
  const deleteItem = (productId) => {

    fetch("http://localhost:9091/api/cart/delete", {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json"
      },
      credentials: "include",
      body: JSON.stringify({
        username: username,
        productId: productId
      })
    }).then(loadCart);
  };

  return (
    <div style={{ padding: "20px" }}>

      <h2>Your Cart</h2>

      {cart.map(item => (
        <div key={item.product_id}>

          <h3>{item.name}</h3>
          <p>{item.description}</p>

          <button onClick={() =>
            updateQty(item.product_id,
                      item.quantity - 1)
          }>
            -
          </button>

          {item.quantity}

          <button onClick={() =>
            updateQty(item.product_id,
                      item.quantity + 1)
          }>
            +
          </button>

          <button onClick={() =>
            deleteItem(item.product_id)
          }>
            Remove
          </button>

        </div>
      ))}

      <h2>Total ₹{total}</h2>

    </div>
  );
}

export default Cart;