import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./UserCartPage.css";
import { MdDeleteOutline } from "react-icons/md";

function UserCartPage() {

  const [cartProducts, setCartProducts] = useState([]);
  const [totalPrice, setTotalPrice] = useState(0);

  const navigate = useNavigate();

  // ===== FETCH CART ITEMS =====
  const loadCart = () => {
    fetch("http://localhost:9091/api/cart/items", {
      credentials: "include"
    })
      .then(res => res.json())
      .then(data => {
        if (data.cart) {
          setCartProducts(data.cart.products || []);
          setTotalPrice(data.cart.overall_total_price || 0);
        } else {
          setCartProducts([]);
        }
      })
      .catch(err => console.error(err));
  };

  useEffect(() => {
    loadCart();
  }, []);

  // ===== UPDATE QUANTITY =====
  const updateQuantity = (productId, qty) => {

    if (qty <= 0) {
      deleteItem(productId);
      return;
    }

    fetch("http://localhost:9091/api/cart/update", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({
        productId,
        quantity: qty
      })
    }).then(loadCart);
  };

  // ===== DELETE ITEM =====
  const deleteItem = (productId) => {
    fetch("http://localhost:9091/api/cart/delete", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ productId })
    }).then(loadCart);
  };

  // ===== CHECKOUT PAYMENT =====
 const handleCheckout = async () => {
  try {

    const cartItems = cartProducts.map(item => ({
      productId: item.product_id,
      quantity: item.quantity,
      price: Number(item.price_per_unit || item.price)
    }));
    

   const finalAmount = Number(totalPrice) + 370;

    // STEP 1 — CREATE ORDER
    const res = await fetch(
      "http://localhost:9091/api/payment/create",
      {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          totalAmount: finalAmount,
          cartItems
        })
      }
    );

    // ⭐ IMPORTANT CHECK
    if (!res.ok) {
      const msg = await res.text();
      console.error("Create Order Error:", msg);
      alert("Order creation failed");
      return;
    }

    const responseText = await res.text();
console.log("CREATE ORDER RESPONSE:", responseText);

const razorpayOrderId = responseText;

    // STEP 2 — OPEN RAZORPAY
    const options = {
      key: "rzp_test_SL82UFwKphgvso",
     amount: Math.round(finalAmount * 100),
      currency: "INR",
      name: "ShopMitra",
      description: "Order Payment",
      order_id: razorpayOrderId,

      handler: async function (response) {

        const verifyRes = await fetch(
          "http://localhost:9091/api/payment/verify",
          {
            method: "POST",
            credentials: "include",
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              razorpayOrderId: response.razorpay_order_id,
              razorpayPaymentId: response.razorpay_payment_id,
              razorpaySignature: response.razorpay_signature
            })
          }
        );

        if (verifyRes.ok) {
          navigate("/orders");
        } else {
          alert("Payment verification failed");
        }
      },

      theme: {
        color: "#ff6b00"
      }
    };
    

   const rzp = new window.Razorpay(options);

rzp.on("payment.failed", function (response) {
  console.log("RAZORPAY ERROR:", response.error);
  alert("Payment Failed: " + response.error.description);
});

rzp.open();

  } catch (err) {
    console.error(err);
    alert("Payment failed");
  }
};
  return (
    <div className="cart-page">
          <button
    className="continue-shopping-btn"
    onClick={() => navigate("/products")}
  >
    ← Continue Shopping
  </button>

      <div className="cart-header">
        <h2>Shopping Cart</h2>
      </div>

      {cartProducts.length === 0 ? (

        <div style={{ textAlign: "center", marginTop: "80px" }}>
          <h2>Your Cart is Empty 🛒</h2>
          <p>Add products to continue shopping</p>
   

          <button
            style={{
              marginTop: "20px",
              padding: "12px 25px",
              background: "#ff6b00",
              color: "white",
              border: "none",
              borderRadius: "8px"
            }}
            onClick={() => navigate("/products")}
          >
            Continue Shopping
          </button>
        </div>

      ) : (

        <div className="cart-container">
          

          <div className="cart-items">
          

            {cartProducts.map(item => (
              <div className="cart-card" key={item.product_id}>

                <img src={item.image_url} alt={item.name} className="cart-img" />

                <div className="cart-info">
                  <h3>{item.name}</h3>
                  <p>{item.description}</p>
                </div>

                <div className="qty-box">
                  <button onClick={() =>
                    updateQuantity(item.product_id, item.quantity - 1)
                  }>
                    -
                  </button>

                  <span>{item.quantity}</span>

                  <button onClick={() =>
                    updateQuantity(item.product_id, item.quantity + 1)
                  }>
                    +
                  </button>
                </div>

                <h4>₹{Number(item.total_price).toFixed(2)}</h4>

                <button
                  className="delete-btn"
                  onClick={() => deleteItem(item.product_id)}
                >
                  <MdDeleteOutline />
                </button>

              </div>
            ))}

          </div>

          <div className="summary">

            <h3>Order Summary</h3>

            <div className="summary-row">
              <span>Subtotal</span>
              <span>₹{Number(totalPrice).toFixed(2)}</span>
            </div>

            <div className="summary-row">
              <span>Shipping</span>
              <span>₹370.00</span>
            </div>

            <div className="summary-row">
              <span>Total Products</span>
              <span>{cartProducts.length}</span>
            </div>

            <hr />

            <div className="summary-row total">
              <span>Total</span>
              <span>₹{Number(totalPrice + 370).toFixed(2)}</span>
            </div>

            {/* ⭐ CHECKOUT BUTTON */}
            <button
              className="checkout-btn"
              onClick={handleCheckout}
            >
              Proceed to Checkout
            </button>

          </div>

        </div>
      )}
    </div>
  );
}

export default UserCartPage;