import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import "./Login.css";

function Login() {

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const navigate = useNavigate();

  // ===== LOGIN FUNCTION =====
  const handleLogin = async () => {

    try {

      const response = await fetch("http://localhost:9091/api/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        credentials: "include",
        body: JSON.stringify({
          username,
          password
        })
      });

      const data = await response.json();

      console.log("LOGIN RESPONSE:", data);

      // ❌ LOGIN FAILED
      if (!response.ok) {
        setError(data.error || "Invalid username or password");
        return;
      }

      // ✅ LOGIN SUCCESS
      localStorage.setItem("username", data.username || username);
      localStorage.setItem("email", username);

      if (data.role) {
        localStorage.setItem("role", data.role);
      }

     if(data.role === "ADMIN"){
    navigate("/admin/products");
}else{
    navigate("/products");
}

    } catch (error) {
      console.error("Login Error:", error);
      setError("Server error. Please try again.");
    }
  };

  return (
    <div className="login-container">

      <div className="page-bg-text">ShopMitra</div>

      <div className="login-card">

        <h2>
          <span className="orange">Login</span>
        </h2>

        {/* ERROR MESSAGE */}
        {error && (
          <p style={{color:"red", marginBottom:"10px"}}>
            {error}
          </p>
        )}

        <input
          placeholder="Enter Email"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />

        <input
          type="password"
          placeholder="Enter Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <button
          className="login-btn"
          onClick={handleLogin}
        >
          Login
        </button>

        <p className="login-link">
          New User? <Link to="/register">Register here</Link>
        </p>

      </div>

    </div>
  );
}

export default Login;