import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./Login";
import RegisterForm from "./RegisterForm";
import Products from "./Products";
import UserCartPage from "./UserCartPage";
import OrdersPage from "./OrdersPage";
import ProfilePage from "./ProfilePage";
import AdminProducts from "./AdminProducts";



function App() {
  return (
    <BrowserRouter>
      <Routes>

        <Route path="/" element={<RegisterForm />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<RegisterForm />} />
        <Route path="/products" element={<Products />} />
        <Route path="/UserCartPage" element={<UserCartPage />} />
        <Route path="/orders" element={<OrdersPage />} />
        <Route path="/profile" element={<ProfilePage />} />
        <Route path="/admin/products" element={<AdminProducts />} />
   

        {/* ADMIN ROUTE */}
      
      </Routes>
    </BrowserRouter>
  );
}

export default App;